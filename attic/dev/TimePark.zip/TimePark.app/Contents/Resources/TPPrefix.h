//
// Prefix header for all source files of the 'TP' target in the 'TP' project
//
#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
    #import "TPCocoaConstants.h"
#endif
/*
#ifndef __PRECISION__
#define __PRECISION__ 0.0000000001
#endif
*/
#ifndef __DEBUG__
//#define __DEBUG__ 1
#endif

#ifndef __DEBUG_EXPORT__
//#define __DEBUG_EXPORT__ 1
#endif

#ifndef __BUILD_GRAPHICAL__
#define __BUILD_GRAPHICAL__ 1
#endif 

#ifndef __DEBUG_DOCUMENT__
//#define __DEBUG_DOCUMENT__ 1
#endif

#ifndef __DEBUG_WINDOW__
//#define __DEBUG_WINDOW__ 1
#endif

#ifndef __DEBUG_GFX__
//#define __DEBUG_GFX__ 1
#endif

#ifndef __DEBUG_EVALUATION__
//#define __DEBUG_EVALUATION__ 1
#endif

#ifndef __DEBUG__2
//#define __DEBUG__2
#endif

#ifndef __DEBUG_SAX__ 
//#define __DEBUG_SAX__ 1
#endif

#ifndef __DEBUG_COCOA__
//#define __DEBUG_COCOA__ 1
#endif

#ifndef __DEBUG__3
//#define __DEBUG__3
#endif
