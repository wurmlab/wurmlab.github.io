# Stats

## Input

```sh

mkdir -p input results

cd input
ln -sf ../../deleterious/results/*csv .
ln -sf ../../advantageous/results/*csv .
ln -sf ../../neutral/results/*csv .
ln -sf ../../dominance/results/*csv .
ln -sf ../../wf_vs_nonwf/results/*csv .

```

## Stats

We ran the `.rmd` script.
