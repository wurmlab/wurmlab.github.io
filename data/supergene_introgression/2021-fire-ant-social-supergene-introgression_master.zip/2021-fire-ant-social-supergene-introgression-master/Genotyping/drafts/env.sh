#!/bin/sh

module load anaconda3
# if doesn't already exist
# conda create -n 2020-05-env freebayes raxml-ng
# conda install -c bioconda vcflib
# conda install -c bioconda vt
# conda install -c bioconda bcftools
# conda install -c bioconda samtools

conda activate 2020-05-env
