To the output of pca_calculation.Rmd we added a column to allow labelling in
plot_pca.Rmd.
  
