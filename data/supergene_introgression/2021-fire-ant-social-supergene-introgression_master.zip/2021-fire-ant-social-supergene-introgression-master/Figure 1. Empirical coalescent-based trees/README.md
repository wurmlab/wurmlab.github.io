tree_converter.ipynb is used to create trees in the correct format to be used as input for tanglegram.R
